<?php
// Heading
$_['heading_title']    = 'Example Plugin';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified the example plugin!';
$_['text_edit']        = 'Edit Example Plugin';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the example plugin!';
