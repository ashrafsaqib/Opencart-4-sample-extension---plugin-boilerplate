<?php
// Heading
$_['heading_title'] = 'Example Plugin';
