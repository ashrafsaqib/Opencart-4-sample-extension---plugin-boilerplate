<?php
class ModelExtensionModuleExamplePlugin extends Model {
    public function getSetting() {
        // Add your model logic here
    }
}
